﻿namespace LoggerApp.Models.Contracts
{
    public interface ILayout
    {
        string FormateError(IError error);
    }
}
