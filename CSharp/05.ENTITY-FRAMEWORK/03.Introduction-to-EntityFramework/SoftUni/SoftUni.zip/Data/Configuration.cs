﻿namespace SoftUni.Data
{
    internal class Configuration
    {
        internal const string CONFIGURATION_STRING = "Server=DESKTOP-FHH8KV4\\SQLEXPRESS;Database=SoftUni;Integrated Security=True;";
    }
}
