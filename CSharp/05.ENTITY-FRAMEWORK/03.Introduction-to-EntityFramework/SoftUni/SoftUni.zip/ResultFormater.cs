﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUni
{
    class ResultFormater
    {
        internal static StringBuilder resultFormater = new StringBuilder();
    }
}
