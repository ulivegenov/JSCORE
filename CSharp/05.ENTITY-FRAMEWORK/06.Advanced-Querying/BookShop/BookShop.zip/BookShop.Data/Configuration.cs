﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-FHH8KV4\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
