﻿namespace P01_StudentSystem.Data
{
    internal class Configuration
    {
        internal const string CONNECTION_STRING = @"Server=DESKTOP-FHH8KV4\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
